/*
Points to note
---------------------------

THIS CODE IS VERY VERY LIKELY TO HAVE BUGS - Happy to meet tuesday to help fix them
Only connects over 2.4ghz
WDT error - too much delay, loop is taking too long to run
Port 23 is reserved for telnet - if this wont work try anything between 1024 - 65000
avoid unnessiery delays
use "arduino timer" instead
very much reccomend https://www.megunolink.com/articles/wireless/talk-esp32-over-wifi/ for information and code


}




*/

#include <WiFi.h>        // Include the Wi-Fi library
#include "ArduinoTimer.h"
 
const char* ssid     = "SSID";         // The SSID (name) of the Wi-Fi network you want to connect to
const char* password = "PASSWORD";     // The password of the Wi-Fi network
const uint ServerPort = 23;             //Chooses a port for TCP server
WiFiServer Server(ServerPort);
 
void setup() {
  Server.begin();               //starts the TCP server
  Serial.begin(115200);         // Start the Serial communication to send messages to the computer
  delay(10);
  Serial.println('\n');
  
  WiFi.begin(ssid, password);             // Connect to the network
  Serial.print("Connecting to ");
  Serial.print(ssid);
 
  while (WiFi.status() != WL_CONNECTED) {        // Wait for the Wi-Fi to connect
    delay(10000);                 //change this if you get the WDT reset error
    Serial.print('.');
  }
 
  Serial.println('\n');
  Serial.println("Connection established!");  
  Serial.print("IP address:\t");
  Serial.println(WiFi.localIP());         // Send the IP address of the ESP8266 to the computer
  }
 

  string command; // make equal to recevied command

  switch (command)
  {
  case 'out' : //move


  default: serial.print("Unrecognized command") //send user "error please try again" message via app
    break;
  }
    
}

WiFiClient RemoteClient;
 
void CheckForConnections()
{
  if (Server.hasClient())
  {
    // If we are already connected to another computer, 
    // then reject the new connection. Otherwise accept
    // the connection. 
    if (RemoteClient.connected())
    {
      Serial.println("Connection rejected");
      Server.available().stop();
    }
    else
    {
      Serial.println("Connection accepted");
      RemoteClient = Server.available();
    }
  }
}

void loop(){
  int command = EchoReceivedData();
  switch (expression)
  {
  case "Received command" :
    break;
  
  default:
    break;
  }
}


void EchoReceivedData() //Recieve data from tcp client
{
  uint8_t ReceiveBuffer[30];
  while (RemoteClient.connected() && RemoteClient.available())
  {
    int Received = RemoteClient.read(ReceiveBuffer, sizeof(ReceiveBuffer));
    RemoteClient.write(ReceiveBuffer, Received);
  }
}



/*
Other stuff you might need



Send data to remote client
#include "MegunoLink.h"
  :
  :
void SendHallValue()
{
  if (RemoteClient.connected())
  { 
    TimePlot HallPlot("", RemoteClient);
    HallPlot.SendData("Magnetic Field", hallRead());
  }
}

Recieve data from TCP client

void EchoReceivedData()
{
  uint8_t ReceiveBuffer[30];
  while (RemoteClient.connected() && RemoteClient.available())
  {
    int Received = RemoteClient.read(ReceiveBuffer, sizeof(ReceiveBuffer));
    RemoteClient.write(ReceiveBuffer, Received);
  }
}

 
ArduinoTimer SendTimer;
  :
void loop() 
{
  CheckForConnections();
  
  if (SendTimer.TimePassed_Milliseconds(delay))
  {
    SendSensorValue();
  }

  /*

  