package com.example.wheeliesmartv1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add_new_bin.*

class AddNewBin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_new_bin)

        val submitBtn = findViewById<Button>(R.id.submitNewBinBtn)

        val binNameVal = findViewById<EditText>(R.id.binName)

        val binCodeVal = findViewById<EditText>(R.id.binCode)

        submitBtn.setOnClickListener {

            val binNameVal2 = binName.text.toString()

            Toast.makeText(this, binNameVal2, Toast.LENGTH_SHORT).show()
            //binNameVal.setText(binName.text)
            //binCodeVal.setText(binCode.text)

            val createBin = Intent(this, BinSuccessPage::class.java)
            createBin.putExtra("name", binNameVal.getText().toString())
            createBin.putExtra("code", binCodeVal.getText().toString())
            startActivity(createBin)

        }


    }
}
