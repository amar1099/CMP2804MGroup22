package com.example.wheeliesmartv1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class BinSuccessPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bin_success_page)

        val name = intent.getStringExtra("name")
        val code = intent.getStringExtra("code")

        val confirmationText = findViewById<TextView>(R.id.confirmationText)

        Toast.makeText(this, name, Toast.LENGTH_SHORT).show()

        confirmationText.text = getString(R.string.placeholder_setup_confirmation_text, name);

        val scheduleBtn = findViewById<Button>(R.id.scheduleBtn)

        scheduleBtn.setOnClickListener {

            val moveToUpdateSchedule = Intent(this, ScheduleBin::class.java)
            startActivity(moveToUpdateSchedule)
        }


    }
}
