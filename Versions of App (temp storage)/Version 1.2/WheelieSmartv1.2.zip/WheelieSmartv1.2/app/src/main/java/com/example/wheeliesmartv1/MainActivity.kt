package com.example.wheeliesmartv1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val addNewBinBtn = findViewById<Button>(R.id.addBinBtn)
        addNewBinBtn.setOnClickListener()
        {
            val intent = Intent(this, AddNewBin::class.java)
            startActivity(intent)
        }
        val manageBinsBtn = findViewById<Button>(R.id.manageBinsBtn)
        manageBinsBtn.setOnClickListener()
        {
            val intent = Intent(this, AddNewBin::class.java)
            startActivity(intent)
        }
        val settingsBtn = findViewById<Button>(R.id.settingsBtn)
        settingsBtn.setOnClickListener()
        {
            val intent = Intent(this, AddNewBin::class.java)
            startActivity(intent)
        }


    }



    






}
