package com.example.wheeliesmartv1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.io.Serializable



class BinSuccessPage : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bin_success_page)

        val newBin = intent.getSerializableExtra("newBin") as Bin

        val confirmationText = findViewById<TextView>(R.id.confirmationText)

        confirmationText.text = getString(R.string.placeholder_setup_confirmation_text, newBin.bName)

        val scheduleBtn = findViewById<Button>(R.id.scheduleBtn)

        scheduleBtn.setOnClickListener {
            val moveToUpdateSchedule = Intent(this, ScheduleBin::class.java)
            moveToUpdateSchedule.putExtra("newBin", newBin as Serializable)
            startActivity(moveToUpdateSchedule)
        }


    }
}
