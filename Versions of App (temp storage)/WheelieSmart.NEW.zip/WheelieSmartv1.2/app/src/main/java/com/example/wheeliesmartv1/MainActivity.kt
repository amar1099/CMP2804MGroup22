package com.example.wheeliesmartv1

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.gson.GsonBuilder
import java.util.*
import kotlin.collections.ArrayList
import com.google.gson.reflect.TypeToken
import com.google.gson.Gson
import android.preference.PreferenceManager
import android.content.Context.MODE_PRIVATE
import java.io.*
import java.lang.reflect.Type


class Bin: Serializable
{
    var bName: String = " "
    var bCode: String = " "
    var day = "yaba daba doooo"
    val test = "Monday"
    //var cal: Calendar = Calendar.getInstance()

    var goingOutSettings: Calendar = Calendar.getInstance()


    val calList = ArrayList<Calendar>()
}

//Monday: 12.07 / Tuesday 11:04

data class ListOfBins(var bin: List<Bin>): Serializable

var binList = ArrayList<Bin>()
var tempList = ArrayList<Bin>()
var joinedList = ArrayList<Bin>()
class MainActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //To do:
        //Send signal to Azure server.

        val addNewBinBtn = findViewById<Button>(R.id.addBinBtn)
        addNewBinBtn.setOnClickListener()
        {
            val intent = Intent(this, AddNewBin::class.java)
            startActivity(intent)
        }
        val manageBinsBtn = findViewById<Button>(R.id.manageBinsBtn)
        manageBinsBtn.setOnClickListener()
        {
            val intent = Intent(this, ManageBins::class.java)
            startActivity(intent)
        }
        val settingsBtn = findViewById<Button>(R.id.settingsBtn)
        settingsBtn.setOnClickListener()
        {
            val intent = Intent(this, AddNewBin::class.java)
            startActivity(intent)
        }




    }










}
