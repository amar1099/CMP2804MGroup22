package com.example.wheeliesmartv1

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_manage_bins.*
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Type
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat


class ManageBins : AppCompatActivity() {

    var binListToDisplay = ArrayList<Bin>()

    fun objectToBytArray(ob: Any): ByteArray? {
        return ob.toString().toByteArray()
    }

    fun uploadBins()
    {


        val serverURL: String = "https://aptempsensor.azurewebsites.net/api/WheelieData"
        val gson = Gson()
        val url = URL(serverURL)

        val arrayToSend = JsonArray()
        for((index, value) in binList.withIndex())
        {
            arrayToSend.add(gson.toJson(value))
        }

        objectToBytArray(arrayToSend)




        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 300000
        connection.connectTimeout = 300000
        connection.doOutput = true

        connection.setRequestProperty("charset", "utf-8")
        connection.setRequestProperty("Content-length", arrayToSend.toString())
        connection.setRequestProperty("Content-Type", "application/json")

        try
        {
            val outputStream: DataOutputStream = DataOutputStream(connection.outputStream)
            outputStream.writeUTF(arrayToSend.toString())

            outputStream.flush()
        }
        catch (exception: Exception) {

        }
        /*
       if (connection.responseCode != HttpURLConnection.HTTP_OK && connection.responseCode != HttpURLConnection.HTTP_CREATED) {
           try {

               println("Error")
               System.exit(0)

           } catch (exception: Exception) {
               throw Exception("Exception while push the notification  $exception.message")
           }
       }
       */
    }
    fun loadData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("task_list.txt", null)
        val type: Type = object : TypeToken<ArrayList<Bin?>?>() {}.type
        binList = gson.fromJson(json, type)

        //binList.distinctBy { Pair(binList, tempList) }
    }
    fun saveData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(binList)
        editor.putString("task_list.txt", json)
        editor.apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_bins)

        loadData()

        val moveHome = findViewById<Button>(R.id.homeBtn)
        val saveBins = findViewById<Button>(R.id.saveBtn)

        for((index, value) in binList.withIndex())
        {
            val tvDynamic = TextView(this)

            tvDynamic.textSize = 20f

            tvDynamic.text = getString(R.string.bin_stats,  value.bName,  value.bCode, SimpleDateFormat("HH:mm").format(value.goingOutSettings.time), value.day)
            tvDynamic.setPadding(20,10,20,10)
            ll_main_layout.addView(tvDynamic)
        }



        moveHome.setOnClickListener {
            val updateSchedule = Intent(this, AddNewBin::class.java)
            startActivity(updateSchedule)
        }
        saveBins.setOnClickListener {
            saveData()
            uploadBins()
        }

        /*
        for((index, value) in binList.withIndex())
        {
            var whatTime = StringBuilder()
            val tvDynamic = TextView(this)
            tvDynamic.textSize = 20f
            for((index, date) in value.date.withIndex())
            {
                val tempStorage = SimpleDateFormat("HH:mm").format(date)

                whatTime.append(tempStorage)
                whatTime.append("/ ")

                // add TextView to LinearLayout

            }
            tvDynamic.text = getString(R.string.bin_stats,  value.bName,  value.bCode, whatTime.toString())
            tvDynamic.setPadding(20,10,20,10)
            ll_main_layout.addView(tvDynamic)
        }
        */





    }
}
