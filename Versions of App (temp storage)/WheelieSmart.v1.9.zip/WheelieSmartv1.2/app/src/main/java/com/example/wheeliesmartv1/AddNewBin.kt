package com.example.wheeliesmartv1

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_add_new_bin.*
import java.io.Serializable


class AddNewBin : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_new_bin)

        val submitBtn = findViewById<Button>(R.id.submitNewBinBtn)

        val binNameTemp = findViewById<EditText>(R.id.binName)
        val binCodeTemp = findViewById<EditText>(R.id.binCode)

        submitBtn.setOnClickListener {

            val newBin = Bin()
            newBin.bCode = binCodeTemp.text.toString()
            newBin.bName = binNameTemp.text.toString()
            //Toast.makeText(this, newBin.bName, Toast.LENGTH_SHORT).show()

            //binList.add(newBin)
            //saveData()

            val createBin = Intent(this, BinSuccessPage::class.java)
            createBin.putExtra("newBin", newBin as Serializable)
            startActivity(createBin)
        }


    }
}
