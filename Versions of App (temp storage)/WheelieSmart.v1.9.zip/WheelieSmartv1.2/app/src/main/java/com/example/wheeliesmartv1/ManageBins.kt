package com.example.wheeliesmartv1

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_manage_bins.*
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.lang.reflect.Type
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat


class ManageBins : AppCompatActivity() {

    var binListToDisplay = ArrayList<Bin>()

    fun objectToBytArray(ob: Any): ByteArray? {
        return ob.toString().toByteArray()
    }

    fun uploadBins() {
        val serverURL: String = "https://aptempsensor.azurewebsites.net/api/HttpTrigger2"
        val gson = Gson()
        val url = URL(serverURL)

        var tempBin = Bin()

        val arrayToSend = JsonArray()
        for ((index, value) in binList.withIndex()) {
            tempBin.bName = "\\" + value.bName + "\\"
            tempBin.bCode = "\\" + value.bCode + "\\"
            tempBin.day = "\\" + value.day + "\\"

            arrayToSend.add(gson.toJson(tempBin))
        }

        objectToBytArray(arrayToSend)

        val connection = url.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 300000
        connection.connectTimeout = 300000
        connection.doOutput = true

        connection.setRequestProperty("charset", "utf-8")
        connection.setRequestProperty("Content-length", arrayToSend.toString())
        connection.setRequestProperty("Content-Type", "application/json")

        try {
            val outputStream: DataOutputStream = DataOutputStream(connection.outputStream)
            outputStream.writeUTF(arrayToSend.toString())

            outputStream.flush()
        } catch (exception: Exception) {

        }

    }

    fun loadData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("task_list.txt", null)
        val type: Type = object : TypeToken<ArrayList<Bin?>?>() {}.type
        binList = gson.fromJson(json, type)

        //binList.distinctBy { Pair(binList, tempList) }
    }

    fun saveData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(binList)
        editor.putString("task_list.txt", json)
        editor.apply()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_bins)

        loadData()

        var intCount: Int = 0

        var stringNames = ArrayList<String>()

        for ((index, value) in binList.withIndex()) {
            value.numberInArray = intCount
            intCount += 1

            stringNames.add(value.bName)

            val tvDynamic = TextView(this)

            tvDynamic.textSize = 20f

            tvDynamic.text = getString(
                R.string.bin_stats,
                value.bName,
                value.bCode,
                value.day
            )
            tvDynamic.setPadding(20, 10, 20, 10)
            ll_main_layout.addView(tvDynamic)

            val moveHome = findViewById<Button>(R.id.homeBtn)
            val saveBins = findViewById<Button>(R.id.saveBtn)
            val removeBinText = findViewById<EditText>(R.id.binToRemove)
            val removeBinBtn = findViewById<Button>(R.id.removeBinBtn)

            val textToChange = findViewById<TextView>(R.id.textView5)
            //val removeBin = findViewById<Button>(R.id.removeBinBtn)

            removeBinBtn.setOnClickListener {

                for ((index, value) in binList.withIndex()) {
                    if (value.bCode == binToRemove.text.toString()) {
                        binList.removeAt(value.numberInArray)
                    }
                }
            }

            moveHome.setOnClickListener {
                val moveToHome = Intent(this, MainActivity::class.java)
                startActivity(moveToHome)
            }
            saveBins.setOnClickListener {
                saveData()
                uploadBins()
            }
        }
    }
}


