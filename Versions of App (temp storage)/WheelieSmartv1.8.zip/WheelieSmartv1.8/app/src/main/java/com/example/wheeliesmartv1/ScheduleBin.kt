package com.example.wheeliesmartv1

import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.gson.Gson
import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*



class ScheduleBin : AppCompatActivity() {

    fun saveData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(binList)
        editor.putString("task_list.txt", json)
        editor.apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule_bin)
        //ModelPreferencesManager.with(this)

        val newBin = intent.getSerializableExtra("newBin") as Bin

        val mondayPickTimeBtn = findViewById<Button>(R.id.monday_btn)
        val tuesdayPickTimeBtn = findViewById<Button>(R.id.tuesday_btn)
        val wednesdayPickTimeBtn = findViewById<Button>(R.id.wednesday_btn)
        val thursdayPickTimeBtn = findViewById<Button>(R.id.thursday_btn)
        val fridayPickTimeBtn = findViewById<Button>(R.id.friday_btn)
        val saturdayPickTimeBtn = findViewById<Button>(R.id.saturday_btn)
        val sundayPickTimeBtn = findViewById<Button>(R.id.sunday_btn)

        val updateScheduleBtn = findViewById<Button>(R.id.update_schedule_btn)

        val displayTime = findViewById<TextView>(R.id.timeTv)

        var tempTimeHolder: String

        updateScheduleBtn.setOnClickListener {
            val updateSchedule = Intent(this, ManageBins::class.java)
            updateSchedule.putExtra("newBin", newBin as Serializable)
            binList.add(newBin)
            saveData()
            startActivity(updateSchedule)

        }

        mondayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                //cal.set(Calendar.DAY_OF_WEEK, 1)
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                //displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)

            }
            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()

            //newBin.calList.add(cal)

            newBin.day = "Monday"

            newBin.goingOutSettings = cal

        }
        tuesdayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Tuesday"

            newBin.goingOutSettings = cal
        }
        wednesdayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Wednesday"

            newBin.goingOutSettings = cal
        }
        thursdayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Thursday"

            newBin.goingOutSettings = cal
        }
        fridayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Friday"

            newBin.goingOutSettings = cal
        }
        saturdayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Saturday"

            newBin.goingOutSettings = cal
        }
        sundayPickTimeBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                displayTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }

            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            newBin.day = "Sunday"

            newBin.goingOutSettings = cal
        }


    }
}
